//
//  LoginViewController.m
//  LoveLife
//
//  Created by qianfeng on 16/1/6.
//  Copyright © 2016年 QF. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    self.view.backgroundColor = RGB(156, 28, 169, 1);
    [super viewDidLoad];
    [self createUI];
}

- (void)createUI{
    NSArray *arr = @[@"sina",@"qq",@"weixin.jpg"];
    for (int i = 0; i < arr.count; i ++) {
        UIButton *button = [FactoryUI createButtonWithFrame:CGRectMake(i *SizeW/3, 200, 50, 50) title:nil titleColor:nil imageName:arr[i] backgroundImageName:nil target:self selector:@selector(logoButtonClick:)];
        button.tag = 10 + i;
        [self.view addSubview:button];
    }
}
//第三方登陆
- (void)logoButtonClick:(UIButton *)btn{
    switch (btn.tag - 10) {
        case 0:{
            //新浪登录
            //指定登陆的第三平台
            UMSocialSnsPlatform * platForm = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
            //点击之后的回掉函数
            platForm.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                
                // 获取到用户的信息
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *sinaAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
                    [self saveData:sinaAccount];
//                    //保存数据
//                    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
//                    [user setObject:sinaAccount.userName forKey:@"userName"];
//                    [user setObject:sinaAccount.iconURL forKey:@"iconURL"];
//                    //拿到需要的信息后返回上一界面
//                    [self.navigationController popViewControllerAnimated:YES];
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",sinaAccount.userName,sinaAccount.usid,sinaAccount.accessToken,sinaAccount.iconURL);
                    
                }});

        }
            break;
        case 1:{
            //qq登陆
            UMSocialSnsPlatform * platForm = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQQ];
            //点击之后的回掉函数
            platForm.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                
                // 获取到用户的信息
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *sinaAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQQ];
                    [self saveData:sinaAccount];
                    //                    //保存数据
                    //                    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                    //                    [user setObject:sinaAccount.userName forKey:@"userName"];
                    //                    [user setObject:sinaAccount.iconURL forKey:@"iconURL"];
                    //                    //拿到需要的信息后返回上一界面
                    //                    [self.navigationController popViewControllerAnimated:YES];
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",sinaAccount.userName,sinaAccount.usid,sinaAccount.accessToken,sinaAccount.iconURL);
                    
                }});

        
        }
            break;
        case 2:{
            //微信登陆
            UMSocialSnsPlatform * platForm = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToWechatSession];
            //点击之后的回掉函数
            platForm.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                
                // 获取到用户的信息
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *sinaAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToWechatSession];
                    [self saveData:sinaAccount];
                    //                    //保存数据
                    //                    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                    //                    [user setObject:sinaAccount.userName forKey:@"userName"];
                    //                    [user setObject:sinaAccount.iconURL forKey:@"iconURL"];
                    //                    //拿到需要的信息后返回上一界面
                    //                    [self.navigationController popViewControllerAnimated:YES];
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",sinaAccount.userName,sinaAccount.usid,sinaAccount.accessToken,sinaAccount.iconURL);
                    
                }});

        }
            break;
        default:
            break;
    }
}

- (void)saveData:(UMSocialAccountEntity *)account
{
    //保存数据
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    [user setObject:account.userName forKey:@"userName"];
    [user setObject:account.iconURL forKey:@"iconURL"];
    //拿到需要的信息后返回上一界面
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
