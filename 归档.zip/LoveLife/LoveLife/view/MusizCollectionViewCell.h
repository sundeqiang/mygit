//
//  MusizCollectionViewCell.h
//  LoveLife
//
//  Created by qianfeng on 16/1/4.
//  Copyright © 2016年 QF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusizCollectionViewCell : UICollectionViewCell


@property (nonatomic, strong) UIImageView * imageView;

@property (nonatomic ,strong) UILabel  *titleLable;

@end
