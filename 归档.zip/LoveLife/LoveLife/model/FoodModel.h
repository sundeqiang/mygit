//
//  FoodModel.h
//  LoveLife
//
//  Created by qianfeng on 15/12/31.
//  Copyright © 2015年 QF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoodModel : NSObject
@property (nonatomic ,copy) NSString *content;
@property (nonatomic ,copy) NSString *title;
@property (nonatomic ,copy) NSString *detail;
@property (nonatomic ,copy) NSString *image;
@property (nonatomic ,copy) NSString *video;
@property (nonatomic ,copy) NSString *dishes_id;
//@property (nonatomic ,copy) NSString * dataID;

@end
