//
//  musicModel.h
//  LoveLife
//
//  Created by qianfeng on 16/1/4.
//  Copyright © 2016年 QF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface musicModel : NSObject

@property (nonatomic ,copy) NSString * artist;
@property (nonatomic ,copy) NSString * coverURL;
@property (nonatomic ,copy) NSString * title;
@property (nonatomic ,copy) NSString * url;


@end
