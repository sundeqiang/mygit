//
//  TitleCollectionViewCell.h
//  LoveLife
//
//  Created by qianfeng on 15/12/31.
//  Copyright © 2015年 QF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UILabel * titleLable;
@end
