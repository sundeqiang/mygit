//
//  ArticDetailViewController.m
//  LoveLife
//
//  Created by qianfeng on 15/12/30.
//  Copyright © 2015年 QF. All rights reserved.
//

#import "ArticDetailViewController.h"
#import "DBManager.h"

@interface ArticDetailViewController ()

@end

@implementation ArticDetailViewController

//- (void)viewWillAppear:(BOOL)animated
//{
//    //再次进入时页面的收藏按钮保持收藏状态
//    DBManager *manager = [DBManager defaultManager];
//    if ([manager isHasDataIDFromTable:self.readModel.dataID]){
//        UIButton *button = [self.view viewWithTag:10];
//        button.selected = YES;
//    }
//
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNVC];
    [self createUI];
}
//创建UI
- (void)createUI{
    UIWebView *webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, SizeW, SizeH)];
    //loadHTMLString家在类似标签式的字符串
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:ARTICALDETAILURL,self.readModel.dataID]]]];
    //使webview适应屏幕大小
    webView.scalesPageToFit = YES;
    [self.view addSubview:webView];
    //webview于javaSript的交互
    
    UIButton *button = [FactoryUI createButtonWithFrame:CGRectMake(SizeW - 50, 80, 40, 40) title:nil titleColor:nil imageName:@"iconfont-iconfontshoucang" backgroundImageName:nil target:self selector:@selector(cilecClick:)];
    [button setImage:[UIImage imageNamed:@"iconfont-iconfontshoucang-2"] forState:UIControlStateSelected];
      button.tag = 10;
    [self.view addSubview:button];
  
}

- (void)cilecClick:(UIButton *)button{
    button.selected = YES;
    DBManager *manager = [DBManager defaultManager];
    if ([manager isHasDataIDFromTable:self.readModel.dataID]){
        //说明已经收藏过
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"已收藏" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil ];
        [alert show];
        //ios9以后
//        UIAlertController *alert1 = [UIAlertController alertControllerWithTitle:@"提示" message:@"请不要重复收藏" preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *action = [UIAlertAction actionWithTitle:@"" style:UIAlertActionStyleCancel handler:nil];
//            [alert1 addAction:action];
//        [self presentViewController:alert1 animated:YES completion:nil];
       
    }else
    {
        //未曾收藏，则插入一条数据
        [manager insertDataModel:self.readModel];
    }
}

- (void)setNVC{
    self.titleLable.text = @"详情";
    [self.leftButton setImage:[UIImage imageNamed:@"qrcode_scan_titlebar_back_nor"] forState:UIControlStateNormal];
    [self setLeftButtonclick:@selector(leftButtonclick)];
    [self.rightButton setImage:[UIImage imageNamed:@"qrcode_scan_titlebar_back_nor"] forState:UIControlStateNormal];
    [self setrightButtonclick:@selector(rightButtonclick)];
}

#pragma  mark---- NCV响应事件

- (void)leftButtonclick{
    [self.navigationController popViewControllerAnimated:YES];
}
//分享
- (void)rightButtonclick{
    UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.readModel.dataID]]];
    [UMSocialSnsService presentSnsIconSheetView:self appKey:APPKEY shareText:[NSString stringWithFormat:ARTICALDETAILURL,self.readModel.dataID] shareImage:image shareToSnsNames:@[UMShareToSina,UMShareToQzone,UMShareToTwitter,UMShareToWechatSession,UMShareToWechatTimeline] delegate:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
