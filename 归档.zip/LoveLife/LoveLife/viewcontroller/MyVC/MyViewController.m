//
//  MyViewController.m
//  LoveLife
//
//  Created by qianfeng on 15/12/29.
//  Copyright © 2015年 QF. All rights reserved.
//

#import "MyViewController.h"
#import "AppDelegate.h"
#import "QRCodeGenerator.h"
#import "MyColectionViewController.h"
#import "LoginViewController.h"

@interface MyViewController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>
{
    UITableView *_tableView;
    UIImageView *_headerImageView;
    //夜间模式的view
    UIView *_darkView;
}

//图标
@property (nonatomic ,strong) NSArray *logoArray;
@property (nonatomic ,strong) NSArray *titleArray;
@property (nonatomic, strong) NSMutableArray * dataArray;

@end

@implementation MyViewController

static float ImageOrigiHeight = 200;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.logoArray = @[@"iconfont-iconfontaixinyizhan",@"iconfont-lajitong",@"iconfont-yejianmoshi",@"iconfont-zhengguiicon40",@"iconfont-guanyu"];
    self.titleArray = @[@"我的收藏",@"清理缓存",@"夜间模式",@"推送消息",@"关于"];
    _darkView = [[UIView alloc]initWithFrame:self.view.frame];
    [self settingNVC];
    [self createUI];
    UIImageView *im = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 200, 200)];
    //Size清晰度
    im.image= [QRCodeGenerator qrImageForString:@"www.baidu.com" imageSize:300];
    [self.view addSubview:im];
}
- (void)createUI{
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SizeW, SizeH) style:UITableViewStylePlain];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    [self.view addSubview:_tableView];
    _tableView.tableHeaderView = [[UIView alloc]init];
    _headerImageView = [FactoryUI createImageViewWithFrame:CGRectMake(0, -ImageOrigiHeight, SizeW,ImageOrigiHeight) imageName:@"welcome1"];
    [_tableView addSubview:_headerImageView];
    //设置_tableView的内容从ImageOrigiHeight开始显示
    _tableView.contentInset = UIEdgeInsetsMake(ImageOrigiHeight, 0, 0, 0);
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell){
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        if(indexPath.row == 0|| indexPath.row == 1||indexPath.row == 4){
            //设置尾部
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        if (indexPath.row == 2 || indexPath.row == 3 ){
            UISwitch *swtch = [[UISwitch alloc]initWithFrame:CGRectMake(SizeW - 60, 5, 50, 30)];
            //设置颜色
            swtch.onTintColor = [UIColor greenColor];
            swtch.tag = indexPath.row;
            [swtch addTarget:self action:@selector(cghangdeClick:) forControlEvents:UIControlEventValueChanged];
            [cell.contentView addSubview:swtch];
        }
    }
    cell.textLabel.text = self.titleArray[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.imageView.image = [UIImage imageNamed:self.logoArray[indexPath.row]];
    return cell;
}

- (void)cghangdeClick:(UISwitch *)swith{
    if (swith.tag == 2) {
        //夜间模式
        if (swith.on){
            UIApplication *app = [UIApplication sharedApplication];
            AppDelegate *delegate = app.delegate;
            //设置背景色
            _darkView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.2];
            //关闭view的交互属性
            _darkView.userInteractionEnabled = NO;
            [delegate.window addSubview:_darkView];
        }else
        {
            [_darkView removeFromSuperview];
        }
        
    }
    else
    {
        //推送消息
//        [self floderSizeWithPath:[self getPath]];
        if (swith.on){
            [self createNotification];
        }else
        {
            //取消推送任务
            [self cancleNotification];
        }
    }
}

#pragma mark --- 推送
- (void)createNotification{
    //解决ios8以后本地推送无法接收到推送消息的问题
    float systemVersion = [[UIDevice currentDevice].systemVersion floatValue];
    if (systemVersion >= 8.0){
        //设置推送消息的类型
        UIUserNotificationType type = UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound;
        //将类型添加到系统设置里
        UIUserNotificationSettings *settting = [UIUserNotificationSettings settingsForTypes:type categories:nil];
        //将设置的内容注册到系统管理里面
        [[UIApplication sharedApplication] registerUserNotificationSettings:settting];
        
    }
    //初始化本地推送
    UILocalNotification *locaNote = [[UILocalNotification alloc]init];
    //设置从当前开始什么时候推送
    locaNote.fireDate = [NSDate dateWithTimeIntervalSinceNow:30];
    //设置需要推送的重复周期
    locaNote.repeatInterval = NSCalendarUnitDay;
    //推送时区
    locaNote.timeZone = [NSTimeZone defaultTimeZone];
    //内容
    locaNote.alertBody = @"来报来吧北京";
    //音效
    locaNote.soundName = @"音效";
    //个数
    locaNote.applicationIconBadgeNumber = 1;
    [[UIApplication sharedApplication ] scheduleLocalNotification:locaNote];
}
//取消推送
- (void)cancleNotification{
    //取消全部推送任务
//    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    //特定条件下的任务
    NSArray *array = [[UIApplication sharedApplication] scheduledLocalNotifications];
    for (UILocalNotification *localNote in array) {
        if ([localNote.alertBody isEqualToString:@"来报来吧北京"]){
            [[UIApplication sharedApplication]cancelLocalNotification:localNote];
            //取消推送消息后重置icon的数值
            [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
            //我的收藏
        {
            MyColectionViewController *vc = [[MyColectionViewController alloc]init];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
         case 1:
            //清理缓存
            [self floderSizeWithPath:[self getPath]];
            
        default:
            break;
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //图头放大
    //思路：通过改变ScrollView的偏移量（contentOffset）来改变图片的frame
    if (scrollView == _tableView){
        // 获取偏移量
        CGFloat yoffset = scrollView.contentOffset.y;
        
        CGFloat xoffset = (yoffset + ImageOrigiHeight)/2;
        if (yoffset < -ImageOrigiHeight){
            CGRect rect = _headerImageView.frame;
            //改变imagevie的frame的值
            rect.origin.y = yoffset;
            rect.size.height = -yoffset;
            rect.origin.x = xoffset;
            //fabs取绝对值
            rect.size.width = SizeW + fabs(xoffset) * 2;
            _headerImageView.frame = rect;
        }
    }
}

- (void)settingNVC{
    self.titleLable.text = @"我的";
    //登陆按钮
    [self.rightButton setTitle:@"登陆" forState:UIControlStateNormal];
    [self setrightButtonclick:@selector(rightButtonClick)];
}

- (void)rightButtonClick{
    LoginViewController *logo = [[LoginViewController alloc]init];
    [self.navigationController pushViewController:logo animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -- 清理缓存
//计算缓存大小
//首先需要获取缓存文件路径
- (NSString *)getPath
{
    //
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
    return path;
}


- (CGFloat)floderSizeWithPath:(NSString *)path
{
    //初始化一个文建管理类
    NSFileManager *maanager = [NSFileManager defaultManager];
    CGFloat folerSize =0.0;
    //存在就计算大小
    if ([maanager fileExistsAtPath:path])
    {
        //获取文件夹下的文件目录
        NSArray *fileArray = [maanager subpathsAtPath:path];
        for (NSString *fileName in fileArray) {
            //获取子文件
            NSString *subFile = [path stringByAppendingPathComponent:fileName];
            //获得的是字节数
            long fileSize = [maanager attributesOfItemAtPath:subFile error:nil].fileSize;
            folerSize += fileSize/1024.0/1024.0;
        }
        //删除文件
        [self showTipView:folerSize];
        return folerSize;
    }
    return 0;
}

- (void)showTipView:(CGFloat)floderSize{
    if (floderSize > 0.01){
        //提示用户清除缓存
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"缓存文件有%.2fM,是否清除",floderSize] delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }else
    {
        //提示用户缓存已经清理
        UIAlertView *alertView1 = [[UIAlertView alloc]initWithTitle:@"" message:@"缓存已经清除" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView1 show];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1){
       
        [self clennCancleFileWithPath:[self getPath]];
    }
}

- (void)clennCancleFileWithPath:(NSString *)path
{
     self.view.backgroundColor = [UIColor lightGrayColor];
    NSFileManager * fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:path])
    {
        NSArray * fileArray = [fileManager subpathsAtPath:path];
        for (NSString * fileName in fileArray)
        {
            //如有需要，可以过滤掉不想删除的文件
            if ([fileName hasSuffix:@".caf"])
            {
                NSLog(@"不删除");
            }
            else
            {
                
                NSError *error;
                NSString * absolutePath = [path stringByAppendingPathComponent:fileName];
                [fileManager removeItemAtPath:absolutePath error:&error];
            }
        }
    }
}



@end
