//
//  musicModel.m
//  LoveLife
//
//  Created by qianfeng on 16/1/4.
//  Copyright © 2016年 QF. All rights reserved.
//

#import "musicModel.h"

@implementation musicModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
