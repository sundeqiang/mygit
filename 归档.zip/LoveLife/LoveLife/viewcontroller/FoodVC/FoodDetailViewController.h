//
//  FoodDetailViewController.h
//  LoveLife
//
//  Created by qianfeng on 16/1/4.
//  Copyright © 2016年 QF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoodDetailViewController : UIViewController

@property (nonatomic ,copy) NSString *dataID;

@property (nonatomic ,copy) NSString * title;

@end
