//
//  MyColectionViewController.m
//  LoveLife
//
//  Created by qianfeng on 16/1/6.
//  Copyright © 2016年 QF. All rights reserved.
//

#import "MyColectionViewController.h"
#import "DBManager.h"
#import "ReadModel.h"
#import "ArticViewCell.h"
#import "ArticDetailViewController.h"

@interface MyColectionViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
}
@property (nonatomic ,strong) NSMutableArray *dataArray;

@end

@implementation MyColectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNVC];
    [self createTablView];
    [self loadData];
}

- (void)loadData{
    DBManager *manager = [DBManager defaultManager];
    self.dataArray = [NSMutableArray arrayWithArray:[manager getData]];
    [_tableView reloadData];
}

- (void)setNVC{
    self.titleLable.text = @"我的收藏";
    [self.leftButton setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    [self setLeftButtonclick:@selector(leftCilck)];
}
#pragma mark --响应函数
- (void)leftCilck{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)createTablView{
    _tableView = [[UITableView alloc]initWithFrame:self.view.frame style:UITableViewStylePlain];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    [self.view addSubview:_tableView];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ArticViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell){
        cell = [[ArticViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    if (self.dataArray){
        ReadModel *model = self.dataArray[indexPath.row];
        [cell refreshUI:model ];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;
}

- (UITableViewCellEditingStyle )tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //删除思路：1.先删除数据库中的数据，2.在删除界面的cell。3.刷新数据
    DBManager *manager = [DBManager defaultManager];
    ReadModel *model = self.dataArray[indexPath.row];
    [manager deleteNameFromTable:model.dataID];
    //删除cell
    [self.dataArray removeObjectAtIndex:indexPath.row];
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    //刷新界面
//    [_tableView reloadData];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ArticDetailViewController *vc = [[ArticDetailViewController alloc]init];
    ReadModel *model = self.dataArray[indexPath.row];
    vc.readModel = model;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
