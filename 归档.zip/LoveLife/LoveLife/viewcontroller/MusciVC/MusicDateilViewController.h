//
//  MusicDateilViewController.h
//  LoveLife
//
//  Created by qianfeng on 16/1/4.
//  Copyright © 2016年 QF. All rights reserved.
//

#import "RootViewController.h"

@interface MusicDateilViewController : RootViewController

@property (nonatomic ,copy) NSString * tyedString;
@property (nonatomic ,copy) NSString *  urlString;

@end
