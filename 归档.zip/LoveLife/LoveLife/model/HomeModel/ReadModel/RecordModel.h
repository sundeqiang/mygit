//
//  RecordModel.h
//  LoveLife
//
//  Created by qianfeng on 15/12/31.
//  Copyright © 2015年 QF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecordModel : NSObject

@property (nonatomic ,strong) NSString *pub_time;
@property (nonatomic ,strong) NSString *publisher_name;
@property (nonatomic ,strong) NSString *text;
@property (nonatomic ,strong) NSString *publisher_icon_url;
@property (nonatomic ,strong) NSString *image_url;

@end
