//
//  HomeModel.h
//  LoveLife
//
//  Created by qianfeng on 15/12/29.
//  Copyright © 2015年 QF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeModel : NSObject
@property (nonatomic ,copy) NSString * title;
@property (nonatomic ,copy) NSString * pic;
@property (nonatomic ,copy) NSString * dataID;
@end
