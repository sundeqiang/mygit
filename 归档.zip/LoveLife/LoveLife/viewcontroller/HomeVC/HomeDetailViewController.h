//
//  HomeDetailViewController.h
//  LoveLife
//
//  Created by qianfeng on 15/12/30.
//  Copyright © 2015年 QF. All rights reserved.
//

#import "RootViewController.h"

@interface HomeDetailViewController : RootViewController

@property (nonatomic ,copy) NSString *dataID;

@end
