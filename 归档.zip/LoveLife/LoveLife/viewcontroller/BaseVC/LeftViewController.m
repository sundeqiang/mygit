//
//  LeftViewController.m
//  LoveLife
//
//  Created by qianfeng on 15/12/29.
//  Copyright © 2015年 QF. All rights reserved.
//

#import "LeftViewController.h"

@interface LeftViewController ()
{
    UIImageView *headerImageView;
    UILabel *nickNameLable;
}
@end

@implementation LeftViewController


- (void)viewWillAppear:(BOOL)animated
{
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    [headerImageView sd_setImageWithURL:[NSURL URLWithString:[user objectForKey:@"iconURL"]] placeholderImage:nil];
    nickNameLable.text = [user objectForKey:@"userName"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGB(140, 56, 80, 1);
    //头像
    headerImageView = [FactoryUI createImageViewWithFrame:CGRectMake((SizeW - 100 -80)/2, 80, 80, 80) imageName:nil];
    headerImageView.layer.cornerRadius = 40;
    headerImageView.layer.masksToBounds = YES;
    [self.view addSubview:headerImageView];
    //昵称
    nickNameLable = [FactoryUI createLabelWithFrame:CGRectMake(0, headerImageView.frame.size.height + headerImageView.frame.origin.y + 10, SizeW - 10, 30) text:nil textColor:[UIColor grayColor] font:[UIFont systemFontOfSize:18]];
    [self.view addSubview:nickNameLable];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
